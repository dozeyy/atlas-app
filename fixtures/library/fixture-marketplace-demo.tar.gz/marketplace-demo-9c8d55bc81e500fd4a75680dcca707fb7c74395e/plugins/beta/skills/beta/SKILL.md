---
name: beta
description: Beta fixture skill
---

# beta

Fixture skill text. Nothing here runs.

---
name: alpha
description: Alpha fixture skill
---

# alpha

Fixture skill text. Nothing here runs.

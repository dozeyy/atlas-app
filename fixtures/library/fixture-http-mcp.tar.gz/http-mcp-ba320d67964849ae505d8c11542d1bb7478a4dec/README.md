# http-mcp

Fixture: one remote MCP server.

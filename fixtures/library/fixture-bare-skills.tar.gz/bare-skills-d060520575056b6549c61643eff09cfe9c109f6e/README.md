# bare-skills

Fixture: text-only skills.

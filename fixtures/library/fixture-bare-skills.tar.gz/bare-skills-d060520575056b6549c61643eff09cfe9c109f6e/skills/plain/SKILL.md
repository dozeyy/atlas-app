---
name: plain
description: A text-only fixture skill
---

# plain

Fixture skill text. Nothing here runs.

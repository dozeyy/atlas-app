---
description: Fixture command
---

Create a rule from this conversation.

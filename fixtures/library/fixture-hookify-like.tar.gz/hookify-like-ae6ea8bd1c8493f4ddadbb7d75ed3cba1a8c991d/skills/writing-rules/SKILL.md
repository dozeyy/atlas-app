---
name: writing-rules
description: Fixture skill for writing rules
---

# writing-rules

Fixture skill text. Nothing here runs.

---
name: xlsx
description: Fixture spreadsheet skill
---

# xlsx

Fixture skill text. Nothing here runs.

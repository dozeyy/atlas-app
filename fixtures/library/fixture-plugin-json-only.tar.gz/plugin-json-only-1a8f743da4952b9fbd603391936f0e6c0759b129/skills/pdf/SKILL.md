---
name: pdf
description: Fixture pdf skill
---

# pdf

Fixture skill text. Nothing here runs.

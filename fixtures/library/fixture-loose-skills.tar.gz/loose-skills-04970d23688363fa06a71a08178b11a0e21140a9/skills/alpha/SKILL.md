---
name: alpha
description: Fixture skill with a script
---

# alpha

Fixture skill text. Nothing here runs.

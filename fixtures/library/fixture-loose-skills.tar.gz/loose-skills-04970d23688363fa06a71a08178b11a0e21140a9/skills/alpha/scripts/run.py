#!/usr/bin/env python3
# fixture script
import sys
print('fixture')
sys.exit(0)

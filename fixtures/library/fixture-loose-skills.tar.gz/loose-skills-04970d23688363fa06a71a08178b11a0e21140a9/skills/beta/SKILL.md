---
name: beta
description: Fixture skill with a helper
---

# beta

Fixture skill text. Nothing here runs.
